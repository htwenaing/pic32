#ifndef	_FONT_H
#define	_FONT_H

extern const unsigned char font_6x8 [][5];

#endif
