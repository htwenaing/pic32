
/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
//#include "p32xxxx.h"    //add this for i2c/gpio etc
//#include "driver/i2c/drv_i2c_static.h"
#include "device_drivers.h"
#include "font.h"


static uint32_t ReadCoreTimer(void);

static uint32_t ReadCoreTimer()
{
    volatile uint32_t timer;

    // get the count reg
    asm volatile("mfc0   %0, $9" : "=r"(timer));

    return(timer);
}

/*
#define SYS_CLK_FREQ 200000000
#define us_SCALE   (GetSystemClock()/2000000)
#define ms_SCALE   (GetSystemClock()/2000)
*/
#define GetSystemClock() (SYS_CLK_FREQ)

uint8_t oledBuffer[OLED_SIZE];

/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

// ***************** i2c ***************
//sending hex byte value to I2C e.g. at i2c tx 01,23,45
void SendByteI2C(){
        
    unsigned char i2c_sad;
    unsigned char i2c_reg;
    unsigned char i2c_dat;
    unsigned char i2c_temp2;
    unsigned char i2c_temp1;
    //sad
    i2c_temp2 = str2hex(USB_Out_Buffer[10]);
    i2c_temp1 = str2hex(USB_Out_Buffer[11]);
    i2c_sad = (i2c_temp2 * 16) + i2c_temp1;
    //reg
    i2c_temp2 = str2hex(USB_Out_Buffer[13]);
    i2c_temp1 = str2hex(USB_Out_Buffer[14]);
    i2c_reg = (i2c_temp2 * 16) + i2c_temp1;
    //data
    i2c_temp2 = str2hex(USB_Out_Buffer[16]);
    i2c_temp1 = str2hex(USB_Out_Buffer[17]);
    i2c_dat = (i2c_temp2 * 16) + i2c_temp1;
    //send
    _i2c1WriteByte(i2c_sad,i2c_reg,i2c_dat);
}

//receiving hex byte value from I2C e.g. at i2c rx 01,23,00,b
//receiving hex word value from I2C e.g. at i2c rx 01,23,00,w
void RecByteI2C(uint16_t Data[]){        
    unsigned char i2c_sad;
    unsigned char i2c_reg;
    unsigned char i2c_dat=0;
    unsigned int i2c_dat2=0;
    unsigned char i2c_temp2;
    unsigned char i2c_temp1;
    //sad
    i2c_temp2 = str2hex(USB_Out_Buffer[10]);
    i2c_temp1 = str2hex(USB_Out_Buffer[11]);
    i2c_sad = (i2c_temp2 * 16) + i2c_temp1;
    //reg
    i2c_temp2 = str2hex(USB_Out_Buffer[13]);
    i2c_temp1 = str2hex(USB_Out_Buffer[14]);
    i2c_reg = (i2c_temp2 * 16) + i2c_temp1;
    //data
    i2c_temp2 = str2hex(USB_Out_Buffer[16]);
    i2c_temp1 = str2hex(USB_Out_Buffer[17]);
    i2c_dat = (i2c_temp2 * 16) + i2c_temp1;
    //send
    if(USB_Out_Buffer[19] == 'b'){
        //i2c_dat=_i2c1ReadByte(i2c_sad,i2c_reg);	//
        //Data=_i2c1ReadByte(i2c_sad,i2c_reg);	//
    }
    if(USB_Out_Buffer[19] == 'w'){
        //i2c_dat2=word_read(i2c_sad,i2c_reg);	//
    }   
    //i2c_dat = 0x35;
    i2c_dat=_i2c1ReadByte(i2c_sad,i2c_reg);	//
    Data[0] = (i2c_dat2*256) + i2c_dat;
    //Data[0] = 0x1234;
//I2C
    /*
//usbBlockTx();
USB_In_Buffer[0]='I';	//
USB_In_Buffer[1]='2';	//
USB_In_Buffer[2]='C';	//
USB_In_Buffer[3]=',';	//
//Buf_cnt=4;
    
    if(usb_parse_bool==1){
        putUSBUSART(USB_In_Buffer,Buf_cnt);
        usbBlockTx();
    }else{
        for (i=0; i<Buf_cnt;i++) {
            while( bzUART()); // Wait until the UART module is free
            pcUART(USB_In_Buffer[i]);
        } 
    }
    */
if(USB_Out_Buffer[19] == 'b'){
    //ui2hex_usb(i2c_dat);    
}
if(USB_Out_Buffer[19] == 'w'){
    //ui2hex_usb(i2c_dat2);    
}
     /*
//done
USB_In_Buffer[0]=10;	//
USB_In_Buffer[1]=13;	//
USB_In_Buffer[2]='>';	//
//Buf_cnt=3;
   
    if(usb_parse_bool==1){
        putUSBUSART(USB_In_Buffer,Buf_cnt);
        usbBlockTx();
    }else{
        for (i=0; i<Buf_cnt;i++) {
            while( bzUART()); // Wait until the UART module is free
            pcUART(USB_In_Buffer[i]);
        } 
    }
    */
    //return i2c_dat;
    //return Data;
}


// ******************* Color ************************
// ****************** i2c1 write byte
//static void _i2c1WriteByte(uint8_t addr, uint8_t reg, uint8_t data){
void _i2c1WriteByte(uint8_t addr, uint8_t reg, uint8_t data){    

    X1_I2C_start();
    X1_byte_write(addr);
    X1_byte_write(reg);           
    X1_byte_write(data);   
    X1_I2C_stop();    
}

// ******************* i2c1 read byte
//static uint8_t _i2c1ReadByte(uint8_t addr, uint8_t reg){
extern uint8_t _i2c1ReadByte(uint8_t addr, uint8_t reg){	
	uint8_t data_in;
	
    X1_I2C_start();
    X1_byte_write(addr);
    X1_byte_write(reg);  
	X1_I2C_restart();
	X1_byte_write(addr+1);
	X1_I2C_read_set();	
    //wait for byte
    //while(Y1_I2CxSTATRBF==0){
        //
        Nop();
    //}
    X1_I2C_wait();    
	data_in = Y1_I2CxRCV;  
    X1_I2C_stop();	
	//
    //I2C1STATbits.RBF = 1;
	return data_in;	
}

/*
void _i2c1ReadByteApp( uint8_t addr, uint8_t reg ){
//static uint8_t _i2c1ReadByteApp( uint8_t addr, uint8_t reg, uint8_t data ){    
	//
    uint8_t data;
    //_i2c1WriteByte(addr,reg,0x00);	//power on
	data = _i2c1ReadByte(addr,reg);	//green low byte
    //return data;
}
*/

// ***************** color sensing *********************
void tcs_3414_ini(void)
{	//
    _i2c1WriteByte(0x72,0x80,0x01);	//power on
	_i2c1WriteByte(0x72,0x81,0x12);	//Set manual integration/integrate time 400ms, 0x10=12ms
	_i2c1WriteByte(0x72,0x87,0x20);	//set 16x , divided by 16 (mid sensitive)
}

void tcs_34725_ini(void)
{	//
    _i2c1WriteByte(0x52,0x80,0x01);	//power on
	_i2c1WriteByte(0x52,0x81,0x00);	//0x00,256,700ms,65535
	_i2c1WriteByte(0x52,0x8F,0x02);	//set 16x gain
}

//note: return GRBC (to get RGBC = rgb_data[1,0,2,3])
void tcs_3414_read(uint16_t rgb_data[]){
	uint8_t bl,bh;
	_i2c1WriteByte(0x72,0x80,0x01);	//power on
	_i2c1WriteByte(0x72,0x80,0x03);	//start ADC TCS3414
	DelayMs(500);
    //PauseMs(500);
	_i2c1WriteByte(0x72,0x80,0x01);	//stop ADC TCS3414
	DelayMs(50);
    //PauseMs(50);
	//green
	bl = _i2c1ReadByte(0x72,0x90);	//green low byte
	bh = _i2c1ReadByte(0x72,0x91);	//green hi byte
	rgb_data[1] = (bh*256)+bl;
	//red
	bl = _i2c1ReadByte(0x72,0x92);	//red low byte
	bh = _i2c1ReadByte(0x72,0x93);	//red hi byte
	rgb_data[0] = (bh*256)+bl;	
	//blue
	bl = _i2c1ReadByte(0x72,0x94);	//blue low byte
	bh = _i2c1ReadByte(0x72,0x95);	//blue hi byte
	rgb_data[2] = (bh*256)+bl;
	//clear
	bl = _i2c1ReadByte(0x72,0x96);	//clear low byte
	bh = _i2c1ReadByte(0x72,0x97);	//clear hi byte
	rgb_data[3] = (bh*256)+bl;	
}

//note: return CRGB (to get RGBC = rgb_data[3,0,1,2])
void tcs_34725_read(uint16_t rgb_data[]){
	uint8_t bl,bh;
	_i2c1WriteByte(0x72,0x80,0x01);	//power on
	_i2c1WriteByte(0x72,0x80,0x03);	//start ADC TCS34725
	DelayMs(500);
	_i2c1WriteByte(0x72,0x80,0x01);	//stop ADC TCS34725
	DelayMs(50);
	//clear
	bl = _i2c1ReadByte(0x72,0x94);	//green low byte
	bh = _i2c1ReadByte(0x72,0x95);	//green hi byte
	rgb_data[3] = (bh*256)+bl;
	//red
	bl = _i2c1ReadByte(0x72,0x96);	//red low byte
	bh = _i2c1ReadByte(0x72,0x97);	//red hi byte
	rgb_data[0] = (bh*256)+bl;	
	//green
	bl = _i2c1ReadByte(0x72,0x98);	//blue low byte
	bh = _i2c1ReadByte(0x72,0x99);	//blue hi byte
	rgb_data[1] = (bh*256)+bl;
	//blue
	bl = _i2c1ReadByte(0x72,0x9A);	//clear low byte
	bh = _i2c1ReadByte(0x72,0x9B);	//clear hi byte
	rgb_data[2] = (bh*256)+bl;	
}

/***********************************************************
 *   Millisecond Delay function using the Count register
 *   in coprocessor 0 in the MIPS core.
 *   When running 200 MHz, CoreTimer frequency is 100 MHz
 *   CoreTimer increments every 2 SYS_CLK, CoreTimer period = 10ns
 *   1 ms = N x CoreTimer_period;
 *   To count 1ms, N = 100000 counts of CoreTimer
 *   1 ms = 10 ns * 100000 = 10e6 ns = 1 ms
 *   When running 80 MHz, CoreTimer frequency is 40 MHz 
 *   CoreTimer increments every 2 SYS_CLK, CoreTimer period = 25ns
 *   To count 1ms, N = 40000 counts of CoreTimer
 *   1ms = 25 ns * 40000 = 10e6 ns = 1 ms
 *   ms_SCALE = (GetSystemClock()/2000) @ 200 MHz = 200e6/2e3 = 100e3 = 100000
 *   ms_SCLAE = (GetSystemClock()/2000) @ = 80e6/2e3 = 40e3 = 40000 
 */
 
/**/
void PauseMs(unsigned long int msDelay )
{
      register unsigned int startCntms = ReadCoreTimer();
      register unsigned int waitCntms = msDelay * ms_SCALE;
 
      while( ReadCoreTimer() - startCntms < waitCntms );
}

/***********************************************************
 *   Microsecond Delay function using the Count register
 *   in coprocessor 0 in the MIPS core.
 *   When running 200 MHz, CoreTimer frequency is 100 MHz
 *   CoreTimer increments every 2 SYS_CLK, CoreTimer period = 10ns
 *   1 us = N x CoreTimer_period;
 *   To count 1us, N = 100 counts of CoreTimer
 *   1 us = 10 ns * 100 = 1000 ns  = 1us
 *   When running 80 MHz, CoreTimer frequency is 40 MHz 
 *   CoreTimer increments every 2 SYS_CLK, CoreTimer period = 25ns
 *   To count 1us, N = 40 counts of CoreTimer
 *   1us = 25 ns * 40 = 1000 ns = 1 us
 *   us_SCALE = (GetSystemClock()/2000) @ 200 MHz = 200e6/2e6 = 100 
 *   us_SCLAE = (GetSystemClock()/2000) @ 80 MHz = 80e6/2e6 = 40 
 */
 /**/
void PauseUs(unsigned long int usDelay )
{
      register unsigned int startCnt = ReadCoreTimer();
      register unsigned int waitCnt = usDelay * us_SCALE;
 
      while( ReadCoreTimer() - startCnt < waitCnt );
}

 
// &&&&&&&&&&&&&&&&&&&&&&&&& OLED &&&&&&&&&&&&&&&&&&&&&&&&& 
 
static int ExampleLocalFunction(int param1, int param2)
{
    return 0;
}

static void _i2cWrite(uint8_t reg, uint8_t *data, uint32_t size)
{
    uint8_t *send = data;
	//
    X1_I2C_start();
    X1_byte_write(OLED_ADDRESS << 1);
    X1_byte_write(reg);
    
    while(size--)
    {             
        X1_byte_write(*send);
        send++;
    }    
    X1_I2C_stop();    
}

static void _sendCommand(uint8_t *data, uint32_t size)
{
    _i2cWrite(0x00, data, size);
}

static void _sendData(uint8_t *data, uint32_t size)
{
    _i2cWrite(0x40, data, size);
}

static void _set_display_on_off(bool state)
{
    uint8_t command[1] = { 0xae | (uint8_t)state };
    _sendCommand(command, sizeof(command));
}

static void _set_multiplex_ratio(uint8_t ratio)
{
    uint8_t command[2] = { 0xa8, ratio };
    _sendCommand(command, sizeof(command));
}

static void _set_display_offset(uint8_t offset)
{
    uint8_t command[2] = { 0xd3, offset };
    _sendCommand(command, sizeof(command));
}

static void _set_display_start_line(uint8_t line)
{
    uint8_t command[1] = { 0x40 | line };
    _sendCommand(command, sizeof(command));
}

static void _set_segment_remap(uint8_t remap)
{
    uint8_t command[1] = { 0xa0 | remap };
    _sendCommand(command, sizeof(command));
}

static void _set_com_scan_direction(uint8_t dir)
{
    uint8_t command[1] = { 0xc0 | dir << 3 };
    _sendCommand(command, sizeof(command));
}

static void _set_com_pins_configuration(uint8_t conf, uint8_t remap)
{
    uint8_t command[2] = { 0xda, 0x02 | (conf << 4) | (remap << 5) };
    _sendCommand(command, sizeof(command));
}

static void _set_contrast_control(uint8_t contrast)
{
    uint8_t command[2] = { 0x81, contrast };
    _sendCommand(command, sizeof(command));
}


static void _entire_display_on(uint8_t status)
{
    uint8_t command[1] = { 0xa4 | status };
    _sendCommand(command, sizeof(command));
}

static void _set_inverse_display(uint8_t inverse)
{
    uint8_t command[1] = { 0xa6 | inverse };
    _sendCommand(command, sizeof(command));
}

static void _set_display_clock(uint8_t divider, uint8_t freq)
{
    uint8_t command[2] = { 0xd5, (freq << 4 | divider) };
    _sendCommand(command, sizeof(command));
}

static void _charge_pump_settings(uint8_t on)
{
    uint8_t command[2] = { 0x8d, 0x10 | (on << 2) };
    _sendCommand(command, sizeof(command));
}

static void _set_memory_addressing_mode(uint8_t mode)
{
    uint8_t command[2] = { 0x20, mode };
    _sendCommand(command, sizeof(command));
}

static void _set_column_address(uint8_t start, uint8_t end)
{
    uint8_t command[3] = { 0x21, start, end };
    _sendCommand(command, sizeof(command));
}

static void _set_page_address(uint8_t start, uint8_t end)
{
    uint8_t command[3] = { 0x22, start, end };
    _sendCommand(command, sizeof(command));
}

static inline _swap(uint8_t *a, uint8_t *b)
{
    uint8_t x;
    x = *a;
    *a = *b;
    *b = x;
}

/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    int ExampleInterfaceFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Remarks
    Refer to the example_file.h interface header for function usage details.
 */
void oledInitialize(void)
{    
    X1_InitI2C();
    //BSP_LCDTurnOn();
    /* Send initialization */
    _set_display_on_off(false);
    _set_multiplex_ratio(63);
    //_set_multiplex_ratio(31);
    _set_display_offset(0);
    _set_display_start_line(0);
    
    _set_segment_remap(1);

#if defined(OLED_TYPE_128x64)
   _set_com_pins_configuration(1, 0);
#elif defined(OLED_TYPE_128x32)
   _set_com_pins_configuration(0, 1); 
   //_set_com_pins_configuration(1, 1); //not working well
#endif
    
    _set_com_scan_direction(1);
       
    _set_contrast_control(0x7f);
    _entire_display_on(0);
    _set_inverse_display(0);
    _set_display_clock(0, 15);
    _charge_pump_settings(1);
    _set_display_on_off(true);
    
    _set_memory_addressing_mode(0);
    _set_column_address(0, 127);
 
#if defined(OLED_TYPE_128x64)
   _set_page_address(0, 7);    //64
#elif defined(OLED_TYPE_128x32)
   _set_page_address(0, 3);  //32
#endif    
  
    /* Clear display */
    oledClear();
    oledUpdate();
}

void oledUpdate(void)
{
    _sendData(oledBuffer, OLED_SIZE);
}

void oledUpdate_test1(void)
{
    //adafruit 3527 PiOLED 128x32
    //oledBuffer[0] = 0xff is bmp y0 to y3
    //oledBuffer[128] = 0xff is bmp y4 to y7
    oledBuffer[0] = 0x0f;    
    oledBuffer[128] = 0x02;
    oledBuffer[256] = 0x0f;
    oledBuffer[384] = 0x0f;
    oledBuffer[512] = 0x0f;
    oledBuffer[640] = 0x0f;
}

void oledUpdate_test2(void)
{
    oledBuffer[0] = 0x00;
    oledBuffer[128] = 0x00;
    oledBuffer[256] = 0x00;
    oledBuffer[384] = 0x00;
    oledBuffer[512] = 0x00;
    oledBuffer[640] = 0x00;
}

void oledClear(void)
{
    memset(oledBuffer, 0, OLED_SIZE);
}

void oledDrawPixel(uint8_t Row, uint8_t Column, uint8_t Color)
{
    if(Row < 0 || Row >= HEIGHT || Column < 0 || Column >= WIDTH)
        return;
    if (Color)
        oledBuffer[Row/8 * 128 + Column] |= 1 << (Row % 8);
    else
        oledBuffer[Row/8 * 128 + Column] &= ~(1 << (Row % 8));
}

void oledDrawVLine(uint8_t Row)
{
    uint8_t i;
    for(i = 0; i < HEIGHT; i++)
    {
        oledDrawPixel(i, Row, WHITE);
    }
}

void oledDrawHLine(uint8_t Column)
{
    uint8_t i;
    for(i = 0; i < WIDTH; i++)
    {
        oledDrawPixel(Column, i, WHITE);
    }
}

void oledDrawPixelChar(uint8_t Row, uint8_t Column, uint8_t Color)
{
    if(Row < 0 || Row >= HEIGHT || Column < 0 || Column >= WIDTH)
        return;
#if 0
    if (Color)
        oledBuffer[Row/8 * 128 + Column] |= 1 << (Row % 8);
    else
        oledBuffer[Row/8 * 128 + Column] &= ~(1 << (Row % 8));
#else   // same idea but using bitwise operations (they are faster)
    if (Color)
        oledBuffer[((Row>>3)<<7) + Column] |= 1 << (Row & 7);
    else
        oledBuffer[((Row>>3)<<7) + Column] &= ~(1 << (Row & 7));
#endif
    return;
}

// works only if the Row is divided by 8
void oledDrawPixelChar2(uint8_t Row, uint8_t Column, uint8_t Data)
{
    if(Row < 0 || Row >= HEIGHT || Column < 0 || Column >= WIDTH)
        return;
    oledBuffer[((Row>>3)<<7) + Column] = Data;
    return;
}

void oledClearRow (uint8_t Row, uint8_t Inverse)
{
    uint8_t i;
    if (Inverse)
        for (i=0; i<128; i++)
            oledDrawPixelChar2 (Row<<3, i, 0xFF);
    else
        for (i=0; i<128; i++)
            oledDrawPixelChar2 (Row<<3, i, 0);
}

void oledDrawChar (uint8_t StartRow, uint8_t StartColumn, uint8_t C, uint8_t Inverse)
{
    unsigned char Row, Column, Temp;
    for (Column=0; Column<6; Column++)
    {
        if (Column==5)
            Temp = 0;
        else
            Temp = font_6x8 [C-32][Column];
        if (Inverse)
            Temp = ~Temp;
        for (Row=0; Row<8; Row++)
            oledDrawPixelChar(StartRow+Row, StartColumn+Column, Temp & (1<<Row));
            //oledDrawPixelChar2(StartRow+Row, StartColumn+Column, Temp);
            //oledDrawPixel(StartRow+Row, StartColumn+Column, Temp);
    }       
    return;
}

void oledDrawString (uint8_t x, uint8_t y, uint8_t C[], uint8_t Inverse)
{
    int i;
    for (i=0; C[i]; i++)
        oledDrawChar (x, y+i*6, C[i], Inverse);
    return;
}

void oledDrawString2 (uint8_t x, uint8_t y, uint8_t C[], uint8_t Icnt)
{
    //int i;
    for (Icnt=0; C[Icnt]; Icnt++)
        oledDrawChar (x, y+Icnt*6, C[Icnt], 0);
    return;
}

/**/  
//using i2c1 for oled
void X1_InitI2C(){

	Y1_SCL_DIR = 1;		// Make SDA and 
    //SDA_DIR = 0;		// Make SDA and 
    Nop();
	Y1_SDA_DIR = 1;		// SCK pins input
    //SCK_DIR = 0;		// SCK pins output
    Nop();
    //
    Y1_I2CxCON = 0x8200;
    
#if defined(__32MX440F256H__)
    Y1_I2CxBRG = 398;
    Y1_IEC=1;
#elif defined(__32MX250F128D__)
    Y1_I2CxBRG = 398;
    Y1_IEC=1;
#elif defined(__32MZ2048EFG144__)
    Y1_I2CxBRG = 112; //measured 400K
    Y1_IEC=1;
#endif    
           
}

//wait to complete and timeout
void X1_I2C_wait(){
    //while(!IFS0bits.I2C1MIF);		// Wait for it to complete
	// 
unsigned long int loop;
loop=0;

    while(!Y1_IFS){   //working ok   
		delay(20);	//wait 20 inst cycles (80MHz=12.5nsx20=250ns)
		loop++;
		//if(loop==0x00ffffff)//250ns per count (16bit~26ms)
        if(loop==0x0000ffff)//250ns per count (16bit~26ms)    
			break;
	} 
    Y1_IFS = 0;			// Clear the flag bit   

/*
#if defined(__32MX440F256H__)
 
#elif defined(__32MX250F128D__)
    while(!Y1_IFS){   //working ok   
		delay(20);	//wait 20 inst cycles (80MHz=12.5nsx20=250ns)
		loop++;
		//if(loop==0x00ffffff)//250ns per count (16bit~26ms)
        if(loop==0x00002fff)//250ns per count (16bit~26ms)    
			break;
	} 
    Y1_IFS = 0;			// Clear the flag bit
#elif defined(__32MZ2048EFG144__)
    while(!Y1_IFS){   //working ok   
		delay(20);	//wait 20 inst cycles (80MHz=12.5nsx20=250ns)
		loop++;
		//if(loop==0x00ffffff)//250ns per count (16bit~26ms)
        if(loop==0x00002fff)//250ns per count (16bit~26ms)    
			break;
	} 
    Y1_IFS = 0;			// Clear the flag bit	
#endif   
*/
}

//start I2C
void X1_I2C_start(){
	Y1_I2CxCON = 0x8201;			// Send start bit
    X1_I2C_wait();
}
//stop I2C
void X1_I2C_stop(){
	Y1_I2CxCON = 0x8204;
    X1_I2C_wait();
}
//repeat I2C
void X1_I2C_restart(){
	Y1_I2CxCON = 0x8202;
    X1_I2C_wait();
}
//read setup I2C
void X1_I2C_read_set(){
	Y1_I2CxCON = 0x8208;
    //X1_I2C_wait();
}

//ACK
void X1_I2C_ack(){
	//I2C1CONbits.ACKDT = 0;			// 0 means ACK
	//I2C1CONbits.ACKEN = 1;			// Send ACKDT value
	//while(!IFS0bits.I2C1MIF);		// Wait for it to complete
	//IFS0bits.I2C1MIF = 0;			// Clear the flag bit
    X1_I2C_wait();
}

//NACK
void X1_I2C_nack(){
	//I2C1CONbits.ACKDT = 1;			// 1 means NACK
	//I2C1CONbits.ACKEN = 1;			// Send ACKDT value
	//while(!IFS0bits.I2C1MIF);		// Wait for it to complete
	//IFS0bits.I2C1MIF = 0;			// Clear the flag bit
    X1_I2C_wait();
}

//ack stat
void X1_I2C_ackstat(){
	//ACKDT = 1;			// 1 means NACK
	//ACKEN = 1;			// Send ACKDT value

	//while(!I2C1CONbits.ACKSTAT);		// Wait for it to complete
	//ACKSTAT = 0;			// Clear the flag bit
}

//********** i2c bytes write *********
void X1_byte_write(unsigned char raw_data){
	//
	Y1_I2CxTRN = raw_data;		// Send Byte value
    X1_I2C_wait();

}

// &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& OV7670 &&&&&&&&&&&&&&&&&&&&&&&&&

/*
The OV7670 uses the following formulas to convert RGB (red, green, blue) color information into YUV (4:2:2): [1]

Y = 0.31*R + 0.59*G + 0.11*B
U = B – Y
V = R – Y
Cb = 0.563*(B-Y)
Cr = 0.713*(R-Y)

The following formulas may be used to convert YUV (4:2:2) back to RGB color: [2]

R = Y + 1.402* (Cr – 128)
G = Y – 0.344136*(Cb -128) – 0.714136*(Cr -128)
B = Y + 1.772*(Cb -128)
*/

static void ov7670_i2cWrite(uint8_t reg, uint8_t data)
{
	//pull low gpio
    X1_I2C_start();
    X1_byte_write(camAddr_WR << 1);
    X1_byte_write(reg);           
    X1_byte_write(data);   
    X1_I2C_stop();
    //pull high gpio
}

void ov7670_init(){

	//set up camera
	ov7670_i2cWrite(0x15,32);//pclk does not toggle on HBLANK COM10
	//ov7670_i2cWrite(0x11,32);//Register 0x11 is for pixel clock divider
	ov7670_i2cWrite(REG_RGB444, 0x00);// Disable RGB444
	ov7670_i2cWrite(REG_COM11,226);//enable night mode 1/8 frame rate COM11*/
	//ov7670_i2cWrite(0x2E,63);//Longer delay
	ov7670_i2cWrite(REG_TSLB,0x04);				// 0D = UYVY  04 = YUYV	 
 	ov7670_i2cWrite(REG_COM13,0x88);			   // connect to REG_TSLB
	//ov7670_i2cWrite(REG_COM13,0x8);			   // connect to REG_TSLB disable gamma
	#ifdef rgb565
		ov7670_i2cWrite(REG_COM7, 0x04);		   // RGB + color bar disable 
		ov7670_i2cWrite(REG_COM15, 0xD0);		  // Set rgb565 with Full range	0xD0
	#elif defined rawRGB
		ov7670_i2cWrite(REG_COM7,1);//raw rgb bayer
		ov7670_i2cWrite(REG_COM15, 0xC0);		  //Full range
	#else
		ov7670_i2cWrite(REG_COM7, 0x00);		   // YUV
		//ov7670_i2cWrite(REG_COM17, 0x00);		  // color bar disable
		ov7670_i2cWrite(REG_COM15, 0xC0);		  //Full range
	#endif
	//ov7670_i2cWrite(REG_COM3, 0x04);
	#if defined qqvga || defined qvga
		ov7670_i2cWrite(REG_COM3,4);	// REG_COM3 
	#else
		ov7670_i2cWrite(REG_COM3,0);	// REG_COM3
	#endif
	//ov7670_i2cWrite(0x3e,0x00);		//  REG_COM14
	//ov7670_i2cWrite(0x72,0x11);		//
	//ov7670_i2cWrite(0x73,0xf0);		//
	//ov7670_i2cWrite(REG_COM8,0x8F);		// AGC AWB AEC Unlimited step size
	/*
    ov7670_i2cWrite(REG_COM8,0x88);//disable AGC disable AEC
	ov7670_i2cWrite(REG_COM1, 3);//manual exposure
	ov7670_i2cWrite(0x07, 0xFF);//manual exposure
	ov7670_i2cWrite(0x10, 0xFF);//manual exposure
     */
	#ifdef qqvga
		ov7670_i2cWrite(REG_COM14, 0x1a);		  // divide by 4
		ov7670_i2cWrite(0x72, 0x22);			   // downsample by 4
		ov7670_i2cWrite(0x73, 0xf2);			   // divide by 4
		ov7670_i2cWrite(REG_HSTART,0x16);
		ov7670_i2cWrite(REG_HSTOP,0x04);
		ov7670_i2cWrite(REG_HREF,0xa4);		   
		ov7670_i2cWrite(REG_VSTART,0x02);
		ov7670_i2cWrite(REG_VSTOP,0x7a);
		ov7670_i2cWrite(REG_VREF,0x0a);	
	#endif
	#ifdef qvga
        ov7670_i2cWrite(REG_COM14, 0x19);		 
		ov7670_i2cWrite(0x72, 0x11);	
		ov7670_i2cWrite(0x73, 0xf1);
		ov7670_i2cWrite(REG_HSTART,0x16);
		ov7670_i2cWrite(REG_HSTOP,0x04);
		ov7670_i2cWrite(REG_HREF,0x24);			
		ov7670_i2cWrite(REG_VSTART,0x02);
		ov7670_i2cWrite(REG_VSTOP,0x7a);
		ov7670_i2cWrite(REG_VREF,0x0a);
	#else
		ov7670_i2cWrite(0x32,0xF6);		// was B6  
		ov7670_i2cWrite(0x17,0x13);		// HSTART
		ov7670_i2cWrite(0x18,0x01);		// HSTOP
		ov7670_i2cWrite(0x19,0x02);		// VSTART
		ov7670_i2cWrite(0x1a,0x7a);		// VSTOP
		//ov7670_i2cWrite(0x03,0x0a);		// VREF
		ov7670_i2cWrite(REG_VREF,0xCA);//set 2 high GAIN MSB
	#endif
	//ov7670_i2cWrite(0x70, 0x3a);	   // Scaling Xsc
	//ov7670_i2cWrite(0x71, 0x35);	   // Scaling Ysc
	//ov7670_i2cWrite(0xA2, 0x02);	   // pixel clock delay
	//Color Settings
	//ov7670_i2cWrite(0,0xFF);//set gain to maximum possible
	//ov7670_i2cWrite(0xAA,0x14);			// Average-based AEC algorithm
	ov7670_i2cWrite(REG_BRIGHT,0x00);	  // 0x00(Brightness 0) - 0x18(Brightness +1) - 0x98(Brightness -1)
	ov7670_i2cWrite(REG_CONTRAS,0x40);	 // 0x40(Contrast 0) - 0x50(Contrast +1) - 0x38(Contrast -1)
	//ov7670_i2cWrite(0xB1,0xB1);			// Automatic Black level Calibration
	ov7670_i2cWrite(0xb1,4);//really enable ABLC
	ov7670_i2cWrite(MTX1,0x80);
	ov7670_i2cWrite(MTX2,0x80);
	ov7670_i2cWrite(MTX3,0x00);
	ov7670_i2cWrite(MTX4,0x22);
	ov7670_i2cWrite(MTX5,0x5e);
	ov7670_i2cWrite(MTX6,0x80);
	ov7670_i2cWrite(MTXS,0x9e);
	ov7670_i2cWrite(AWBC7,0x88);
	ov7670_i2cWrite(AWBC8,0x88);
	ov7670_i2cWrite(AWBC9,0x44);
	ov7670_i2cWrite(AWBC10,0x67);
	ov7670_i2cWrite(AWBC11,0x49);
	ov7670_i2cWrite(AWBC12,0x0e);
	ov7670_i2cWrite(REG_GFIX,0x00);
	//ov7670_i2cWrite(GGAIN,0);
	ov7670_i2cWrite(AWBCTR3,0x0a);
	ov7670_i2cWrite(AWBCTR2,0x55);
	ov7670_i2cWrite(AWBCTR1,0x11);
	ov7670_i2cWrite(AWBCTR0,0x9f);
	//ov7670_i2cWrite(0xb0,0x84);//not sure what this does
	ov7670_i2cWrite(REG_COM16,COM16_AWBGAIN);//disable auto denoise and edge enhancement
	//ov7670_i2cWrite(REG_COM16,0);
	ov7670_i2cWrite(0x4C,0);//disable denoise
	ov7670_i2cWrite(0x76,0);//disable denoise
	ov7670_i2cWrite(0x77,0);//disable denoise
	ov7670_i2cWrite(0x7B,4);//brighten up shadows a bit end point 4
	ov7670_i2cWrite(0x7C,8);//brighten up shadows a bit end point 8
	//ov7670_i2cWrite(0x88,238);//darken highlights end point 176
	//ov7670_i2cWrite(0x89,211);//try to get more highlight detail
	//ov7670_i2cWrite(0x7A,60);//slope
	//ov7670_i2cWrite(0x26,0xB4);//lower maximum stable operating range for AEC
	//hueSatMatrix(0,100);
	//ov7670_store_cmatrix();
	//ov7670_i2cWrite(0x20,12);//set ADC range to 1.5x
	ov7670_i2cWrite(REG_COM9,0x6A);//max gain to 128x
	ov7670_i2cWrite(0x74,16);//disable digital gain
	//ov7670_i2cWrite(0x93,15);//dummy line MSB
	ov7670_i2cWrite(0x11,4);
	//ov7670_i2cWrite(0x2a,5);//href delay	
}

//config spi2
void ov7670_spi_config(){
	
#define SCK2		PORTGbits.RG6				// clk
#define SDI2		PORTGbits.RG7				// data in
#define SDO2		PORTGbits.RG8				// data out
#define SS2         PORTGbits.RG9				// ss
#define MMC_SS         PORTBbits.RB13				// mmc ss
    
#define SCK2_DIR		TRISGbits.TRISG6			// 
#define SDI2_DIR		TRISGbits.TRISG7			// 
#define SDO2_DIR		TRISGbits.TRISG8			// 
#define SS2_DIR		TRISGbits.TRISG9			//
#define MMC_SS_DIR         TRISBbits.TRISB13				// mmc ss

    //direction
	//DDPCONbits.JTAGEN = 0;	//very important to disable JTAG if not use
	Nop();
	SCK2_DIR = 0;		//  
    Nop();
	SDI2_DIR = 1;		// 
    Nop();
	SDO2_DIR = 0;		//  
    Nop();
	SS2_DIR = 0;		// 
    Nop();
	MMC_SS_DIR = 0;
    Nop();
	MMC_SS=1;
    Nop();
	
    //spi-clk=Fpb/(2*(brg+1))
    //2clk/bit,32bitsx2=64clkx2ch=128
    //SPI2BRG = 38;   //1.0256 MHz @ 80 MHz (8kspsx128=1.024MHz)  

	//SpiChnOpen(2, SPI_CON_MSTEN | SPI_CON_MODE8 | SPI_CON_ON | SPI_CON_FRMEN, 100);   // divide fpb by 100, configure the I/O ports.	
	//SpiChnOpen(2, SPI_CON_MSTEN | SPI_CON_MODE8 | SPI_CON_ON | SPI_CON_FRMEN, 500); 
	//SPI2CON = 0x8120; // ON, CKE=1; CKP=0, sample middle
	//SPI2BRG = 71; // clock = Fpb/144 = 250kHz	
}



/*
//OV7670 bit banging 
void ov7670_bb_proc(){
//
#define clk_wait 2
#define clk_edge1 0
#define clk_edge2 1
//
#define XCLK_SCK2		PORTGbits.RG6				// clk
#define HRE_SDI2		PORTGbits.RG7				// data in
#define VSY_SDO2		PORTGbits.RG8				// data out
#define PCLK_SS2         PORTFbits.RF0				// ss
#define OV_DATA PORTE
//   
#define XCLK_SCK2_DIR		TRISGbits.TRISG6			// 
#define HRE_SDI2_DIR		TRISGbits.TRISG7			// 
#define VSY_SDO2_DIR		TRISGbits.TRISG8			// 
#define PCLK_SS2_DIR		TRISFbits.TRISF0			//
#define OV_DATA_DIR TRISE

    //direction
	DDPCONbits.JTAGEN = 0;	//very important to disable JTAG if not use
	Nop();
	XCLK_SCK2_DIR = 0;		//xclk out 
    Nop();
	HRE_SDI2_DIR = 1;		// 
    Nop();
	VSY_SDO2_DIR = 1;		//  
    Nop();
	PCLK_SS2_DIR = 1;		// 
    Nop();
	OV_DATA_DIR = 0xffff;
	
	unsigned char ov_raw;
	unsigned char task;
	task = 1;
	
		
	while (1){
		//clk high
		XCLK_SCK2 = ~XCLK_SCK2;
		ov_delay(clk_wait);
		//XCLK_SCK2 = 0;
		//ov_delay(clk_wait);		
	}	
	
	//look for vsyn pulse rise, when low then start	
	//look for it
	while (VSY_SDO2 == 0){
		//
		XCLK_SCK2 = ~XCLK_SCK2;
		ov_delay(clk_wait);	
	}
	//look for it
	while (VSY_SDO2 == 1){
		//
		XCLK_SCK2 = ~XCLK_SCK2;
		ov_delay(clk_wait);	
	}	
	//found sync start
	while (HRE_SDI2 == 1){
		//
		XCLK_SCK2 = ~XCLK_SCK2;
		ov_delay(clk_wait);	
	}	
	while (HRE_SDI2 == 0){
		//
		XCLK_SCK2 = ~XCLK_SCK2;
		ov_delay(clk_wait);	
	}
	//start data
	while (task == 1){
		if(VSY_SDO2 == 0){ 
			if(HRE_SDI2 == 0){
				XCLK_SCK2 = ~XCLK_SCK2;	//nothing to get
				ov_delay(clk_wait);
			}else{
				//row data ready
				if(PCLK_SS2 == 1){
					//get data
					ov_raw = OV_DATA;
					XCLK_SCK2 = ~XCLK_SCK2;
				}else{
					//wait for clk rising
					XCLK_SCK2 = ~XCLK_SCK2;
				}
			}
		}
	}	

}

void ov_delay(unsigned long count)
{
	while(--count);
	Nop();
}
*/

// ************* PWM ********************
void PWM_init()
{
    T3CON   = 0x0;      // Disable timer 2 when setting it up
    TMR3    = 0;        // Set timer 2 counter to 0

    // Set up the period. Period = PBCLK3 frequency, 
    //which is SYS_FREQ / 2, divided by 50 Hhz and 
    //then divided again by 32 for our chosen pre-scaler. 
    PR3 = SYS_CLK_FREQ / 2 / 50 / 32;

    // Set up the pre-scaler
    T3CONbits.TCKPS = 0b101; // Pre-scale of 32

    // Turn on timer 2
    T3CONbits.TON   = 1;

    OC6CON = 0;             // Turn off Output Compare module 6
    OC6CONbits.OCTSEL = 1;  // Interrupt source for this module is Timer 3
    OC6CONbits.OCM = 0b110; // Output Compare Mode (OCM) is 6, which is PWM mode
    OC6RS = 0;              // Keep the signal low for the entire duration
    OC6CONbits.ON = 1;      // Turn on Output Compare module 6 (OC6)
    /* in main() */
    OC6RS = 3125;               //tested 50Hz with 1ms pulse    
}


void delay(unsigned long count)
{
	while(--count);
	Nop();
}

// **************  conversion  ******************

//convert unsigned int to hex and print (format "0x1234,")
extern uint16_t ui2hex_usb(uint16_t Data, uint8_t USB_In_Buffer[]){
int i;
unsigned int s;
unsigned int v;
unsigned char bit_pt;
unsigned char d;
unsigned char dd;
unsigned char x;
unsigned char y;
s=0x8000;
x=0;
y=0;
USB_In_Buffer[0]='0';
USB_In_Buffer[1]='x';
		//start
		while(y<4){//was 6
		bit_pt=8;
		d=0;
		dd=0;
			for (i=0; i<4;i++) {
				v=Data&s;
				if (v==s){
					//one
					d=d+bit_pt;
				}
				bit_pt=bit_pt>>1;
				s=s>>1;
			}
			if(d<10){
				dd=d+0x30;	//convert to 0,1,2
			}
			else{
				dd=d+55;	//convert to A,B,C
			}
			USB_In_Buffer[y+2]=dd;		
			y++;
		}

//
USB_In_Buffer[6]=',';
//Buf_cnt=7;

}

//convert unsigned char to hex and print (format "0x12,")
extern uint8_t uc2hex_usb(uint8_t Data, uint8_t USB_In_Buffer[]){
int i;
unsigned char s;
unsigned char v;
unsigned char bit_pt;
unsigned char d;
unsigned char dd;
unsigned char x;
unsigned char y;
s=0x80;
x=0;
y=0;
USB_In_Buffer[0]='0';
USB_In_Buffer[1]='x';
		//start
		while(y<2){//was 4
		bit_pt=8;
		d=0;
		dd=0;
			for (i=0; i<4;i++) {
				v=Data&s;
				if (v==s){
					//one
					d=d+bit_pt;
				}
				bit_pt=bit_pt>>1;
				s=s>>1;
			}
			if(d<10){
				dd=d+0x30;	//convert to 0,1,2
			}
			else{
				dd=d+55;	//convert to A,B,C
			}
			USB_In_Buffer[y+2]=dd;		
			y++;
		}
//
USB_In_Buffer[4]=',';
//Buf_cnt=5;

}

//convert hex string to decimal value
extern uint8_t str2hex(uint8_t uc_str){
    unsigned char uc_dec;     
    if (uc_str >= '0' && uc_str <= '9'){ //0~9
		uc_dec = uc_str - 0x30;        
	}
    if (uc_str >= 'a' && uc_str <= 'f'){ //a~f
		//uc_dec = uc_str - 0x57;   // 
        uc_dec = uc_str - 87;
	}  
    if (uc_str >= 'A' && uc_str <= 'F'){ //a~f
		//uc_dec = uc_str - 0x37;   // 
        uc_dec = uc_str - 55;
	}    
    return uc_dec;    
}

/* *****************************************************************************
 End of File
 */
